Obrigado por todo conhecimento partilhado em suas aulas prof Masanori.
Deixo salvo que esse programa em si � Open Source, sinta-se livre para compartilha-lo em suas aulas :)