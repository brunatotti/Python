import requests
import json

dici_estd={11:'Rondônia/RO',12:'Acre/AC',13:'Amazonas/AM',
          14:'Roraíma/RR',15:'Pará/PA',16:'Amapá/AP',
          17:'Tocantins/TO',21:'Maranhão/MA',22:'Piauí/PI',
          23:'Ceará/CE',24:'Rio Grande do Norte/RN',25:'Paraíba/PB',
          26:'Pernambuco/PE',27:'Alagoas/AL',28:'Sergipe/SE',
          29:'Bahia/BA',31:'Minas Gerais/MG',
          32:'Espírito Santo/ES',33:'Rio de Janeiro/RJ',35:'São Paulo/SP',
          41:'Paraná/PR',42:'Santa Catarina/SC',43:'Rio Grande do Sul/RS',
          50:'Mato Grosso do Sul/MS',51:'Mato Grosso/MT',52:'Goiás/GO',
          53:'Distrito Federal/DF'} 

url_renda = 'http://api.pgi.gov.br/api/1/serie/2455.json'
data_renda = requests.get(url_renda).content
json_renda = json.loads(data_renda)

renda = {}
for valor_renda in json_renda['valores']:
    if valor_renda['ano'] == 2010:
        renda[valor_renda['estado_ibge']] = valor_renda['valor']
final_renda = {}

for x_renda in [11,12,13,14,15,16,17,21,22,23,24,25,26,27,28,29,31,32,33,35,41,42,43,50,51,52,53]:
    final_renda[dici_estd[x_renda]] = renda[x_renda]           
print(final_renda)


url_edu = 'http://api.pgi.gov.br/api/1/serie/2457.json'
data_edu = requests.get(url_edu).content
json_edu = json.loads(data_edu)

edu = {}
for valor_edu in json_edu['valores']:
    if valor_edu['ano'] == 2010:
        edu[valor_edu['estado_ibge']] = valor_edu['valor']
final_edu = {}

for x_edu in [11,12,13,14,15,16,17,21,22,23,24,25,26,27,28,29,31,32,33,35,41,42,43,50,51,52,53]:
    final_edu[dici_estd[x_edu]] = edu[x_edu]
    
print(final_edu)



